//
//  Index.swift
//  Final
//
//  Created by Chan on 16/6/23.
//  Copyright © 2016年 Chan. All rights reserved.
//

import Foundation
import UIKit

class IndexController: UIViewController,UIScrollViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet weak var galleryScrollerView: UIScrollView!
    @IBOutlet weak var galleryPageController: UIPageControl!
    var timer:NSTimer!
    
    @IBOutlet weak var indexcollection: UICollectionView!
    @IBOutlet weak var textview: UITableView!
    
    let titleArr=["推荐","早餐","甜点","正餐"]
    let iconArr=["推荐.png","早餐.png","午餐.png","晚餐.png"]
    let pushArr=[];
    
    //屏幕尺寸
    let screenbounds:CGRect = UIScreen.mainScreen().bounds
    private let sectionInsets = UIEdgeInsets(top: 0, left: 5.0, bottom: 0.0, right: 5.0)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        pictureGallery();
        indexcollection.layer.backgroundColor=UIColor.clearColor().CGColor
        self.indexcollection.frame.size.width = screenbounds.size.width  * 0.9
        self.indexcollection.frame.size.height = screenbounds.size.height  * 0.05 + 50
        self.textview.frame.size.width = screenbounds.size.width  * 0.9
        indexcollection.delegate=self
        indexcollection.dataSource=self
        textview.delegate=self
        textview.dataSource=self
        textview.separatorStyle=UITableViewCellSeparatorStyle.None
        self.automaticallyAdjustsScrollViewInsets=false
        self.textview.tableFooterView = UIView.init(frame: CGRectZero);
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int{
        return titleArr.count
    }
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell{
        let cell = indexcollection.dequeueReusableCellWithReuseIdentifier("indexcell", forIndexPath: indexPath)
        let icon = cell.viewWithTag(1) as! UIImageView
        let title = cell.viewWithTag(2)as! UILabel
        title.text=titleArr[indexPath.row]
        icon.image=UIImage(named: iconArr[indexPath.row])
        return cell
    }
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        let size:CGSize = self.indexcollection.frame.size
        let widthss:CGFloat = size.width * 0.20
        let heightss:CGFloat = size.height * 0.9
        return CGSize(width: widthss, height: heightss)
    }
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        
        return sectionInsets
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return 1;
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell = textview.dequeueReusableCellWithIdentifier("msgcell", forIndexPath: indexPath) as UITableViewCell!
        let bg = cell.viewWithTag(10) as! UILabel!
        let bg2 = cell.viewWithTag(14) as! myUILabel!
        let title2 = cell.viewWithTag(12) as! UILabel!
        let subtitle = cell.viewWithTag(13) as! UILabel!
        let icon  = cell.viewWithTag(11) as! UIImageView!
        title2!.text = "派送中"
        subtitle.text = "预计将在12:24送达"
        icon.image=UIImage(named: "派送中.png")
        //        bg.layer.borderColor=UIColor.clearColor().CGColor
        bg.layer.cornerRadius = 10.0
        bg.layer.masksToBounds=true
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        bg2.layer.cornerRadius = 10.0
        bg2.layer.masksToBounds=true
        //        bg2.text="\t未完成\n"
        bg2.verticalAlignment=VerticalAlignmentTop
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
    }
    
    //实现图片滚动播放；
    func pictureGallery(){
        self.galleryScrollerView.frame.size.width=screenbounds.size.width
        self.galleryScrollerView.frame.size.height=screenbounds.size.height*0.4
        
        //image width
        let imageW:CGFloat = self.galleryScrollerView.frame.size.width;
        let imageH:CGFloat = self.galleryScrollerView.frame.size.height;
        let imageY:CGFloat = 0;
        let totalCount:NSInteger = 3;//轮播的图片数量；
        for index in 0..<totalCount{
            let imageView:UIImageView = UIImageView();
            let imageX:CGFloat = CGFloat(index) * imageW;
            imageView.frame = CGRectMake(imageX, imageY, imageW, imageH);//设置图片的大小，注意Image和ScrollView的关系，其实几张图片是按顺序从左向右依次放置在ScrollView中的，但是ScrollView在界面中显示的只是一张图片的大小，效果类似与画廊；
            let name:String = String(format: "gallery%d", index+1);
            imageView.image = UIImage(named: name);
            self.galleryScrollerView.showsHorizontalScrollIndicator = false;//不设置水平滚动条；
            self.galleryScrollerView.addSubview(imageView);//把图片加入到ScrollView中去，实现轮播的效果；
        }
        
        //需要非常注意的是：ScrollView控件一定要设置contentSize;包括长和宽；
        let contentW:CGFloat = imageW * CGFloat(totalCount);//这里的宽度就是所有的图片宽度之和；
        self.galleryScrollerView.contentSize = CGSizeMake(contentW, 0);
        self.galleryScrollerView.pagingEnabled = true;
        self.galleryScrollerView.delegate = self;
        self.galleryPageController.numberOfPages = totalCount;//下面的页码提示器；
        self.addTimer()
        
    }
    func nextImage(sender:AnyObject!){
        var page:Int = self.galleryPageController.currentPage;
        if(page == 2){
            page = 0;
        }else{
            page=page+1;
        }
        let x:CGFloat = CGFloat(page) * self.galleryScrollerView.frame.size.width;
        self.galleryScrollerView.contentOffset = CGPointMake(x, 0);//注意：contentOffset就是设置ScrollView的偏移；
    }
    //UIScrollViewDelegate中重写的方法；
    //处理所有ScrollView的滚动之后的事件，注意 不是执行滚动的事件；
    func scrollViewDidScroll(scrollView: UIScrollView) {
        //这里的代码是在ScrollView滚动后执行的操作，并不是执行ScrollView的代码；
        //这里只是为了设置下面的页码提示器；该操作是在图片滚动之后操作的；
        let scrollviewW:CGFloat = galleryScrollerView.frame.size.width;
        let x:CGFloat = galleryScrollerView.contentOffset.x;
        let page:Int = (Int)((x + scrollviewW / 2) / scrollviewW);
        self.galleryPageController.currentPage = page;
        
    }
    func addTimer(){   //图片轮播的定时器；
        self.timer = NSTimer.scheduledTimerWithTimeInterval(5, target: self, selector: #selector(IndexController.nextImage(_:)), userInfo: nil, repeats: true);
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        print(indexPath.row)
        if indexPath.row > 0{
            let mystoryboard = UIStoryboard(name: "meal", bundle: nil).instantiateViewControllerWithIdentifier("meal") as UIViewController
            mystoryboard.navigationItem.title="\(titleArr[indexPath.row])"
            mystoryboard.hidesBottomBarWhenPushed=true;
            self.navigationController?.pushViewController(mystoryboard, animated: true)
        }
        else{
            self.noticeInfo("暂不开放", autoClear: true , autoClearTime: 1)
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.noticeInfo("正在配送中", autoClear: true, autoClearTime: 1)
    }


}

