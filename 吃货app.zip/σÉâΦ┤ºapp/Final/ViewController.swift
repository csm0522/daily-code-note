//
//  ViewController.swift
//  Final
//
//  Created by Chan on 16/6/16.
//  Copyright © 2016年 Chan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var support: myUILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let navtitle = self.navigationItem.title!
        switch navtitle {
        case "技术支持":
             support.text="@弹出框类作者com.lvwenhan\n@MyUIlabel类作者无从考"
            break
            case "开发者信息":
            support.text="1301050005陈少敏"
            break
        default:
           support.text="2016年6月16日开始策划,设计\n2016年6月20日开始进行开发\n2016年6月24日开发结束\n2016年6月25日开始进行测试\n2016年6月25日使用手册v1.0出版\n开发整体结束。"
            break
        }
    
        support.verticalAlignment=VerticalAlignmentTop
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

