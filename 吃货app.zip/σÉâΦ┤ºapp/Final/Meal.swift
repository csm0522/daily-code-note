//
//  Meal.swift
//  Final
//
//  Created by Chan on 16/6/23.
//  Copyright © 2016年 Chan. All rights reserved.
//

import Foundation
import UIKit
var breakfast:[MealModel]=[]
var desert:[MealModel]=[]
var dinner:[MealModel]=[]
var tag:Int=0
class MealController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var Mview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tag=0;
        let nav = self.navigationItem.title
        tag=CheckMeal(nav!)
        
        breakfast=[MealModel(img: "br1.jpeg" , title: "黄油煎蛋加牛奶套餐" , subtitle: "就是个套餐" , money: "25.0"),
                   MealModel(img: "br2.jpeg" , title: "蜂蜜煎饼" , subtitle: "就是煎饼" , money: "5.0"),
                   MealModel(img: "br3.jpeg" , title: "火腿蛋" , subtitle: "" , money: "9.0"),
                   MealModel(img: "br4.jpeg" , title: "烧卖" , subtitle: "" , money: "6.0"),
                   MealModel(img: "br5.jpeg" , title: "公司三明治" , subtitle: "商务套餐" , money: "15.0"),
                   MealModel(img: "br6.jpeg" , title: "公司特制三明治" , subtitle: "高级一点" , money: "25.0"),
                   MealModel(img: "br7.jpeg" , title: "公司顶级三明治" , subtitle: "高级不止一点" , money: "35.0"),
        ]
        desert=[MealModel(img: "desert1.jpeg" , title: "蜂蜜水果茶" , subtitle: "" , money: "15.0"),
                MealModel(img: "desert2.jpeg" , title: "蛋糕加冰淇淋可乐" , subtitle: "" , money: "25.0"),
                MealModel(img: "desert3.jpeg" , title: "蓝莓慕斯切块" , subtitle: "" , money: "15.0"),
                MealModel(img: "desert4.jpeg" , title: "糯米团子串" , subtitle: "" , money: "10.0"),
                MealModel(img: "desert5.jpeg" , title: "蓝莓煎饼" , subtitle: "" , money: "15.0"),
                MealModel(img: "desert7.jpeg" , title: "草莓蛋糕" , subtitle: "" , money: "15.0"),
                MealModel(img: "desert8.jpeg" , title: "高级芝士蛋糕" , subtitle: "" , money: "15.0"),
                MealModel(img: "desert9.jpeg" , title: "草莓脆饼蛋糕" , subtitle: "" , money: "15.0"),
                MealModel(img: "desert10.jpeg" , title: "水果拼盘" , subtitle: "" , money: "25.0"),
                MealModel(img: "desert6.jpeg" , title: "水果派" , subtitle: "" , money: "15.0"),
                MealModel(img: "desert11.jpeg" , title: "水果雪糕饮品" , subtitle: "" , money: "25.0"),
        ]
        dinner=[MealModel(img: "dinner1.jpeg", title: "香菇粉丝面", subtitle: "", money: "18.0"),
                MealModel(img: "dinner2.jpeg", title: "吉列猪排", subtitle: "", money: "18.0"),
                MealModel(img: "dinner3.jpeg", title: "日式咖喱饭", subtitle: "", money: "18.0"),
                MealModel(img: "dinner4.jpeg", title: "黄金蛋包饭", subtitle: "", money: "18.0"),
                MealModel(img: "dinner5.jpeg", title: "海鲜拉面", subtitle: "", money: "18.0"),
                MealModel(img: "dinner6.jpeg", title: "辣火锅", subtitle: "", money: "18.0"),
                MealModel(img: "dinner7.jpeg", title: "煎牛排", subtitle: "", money: "18.0"),
                MealModel(img: "dinner8.jpeg", title: "鳗鱼饭", subtitle: "", money: "18.0"),
                MealModel(img: "dinner9.jpeg", title: "煎饺", subtitle: "", money: "18.0"),
                MealModel(img: "dinner10.jpeg", title: "部队火锅", subtitle: "", money: "18.0"),
                MealModel(img: "dinner11.jpeg", title: "鳗鱼烧", subtitle: "", money: "18.0"),
        ]
        Mview.dataSource=self
        Mview.delegate=self
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        switch tag {
        case 1:return breakfast.count
        case 2:return desert.count
        case 3:return dinner.count
        default:return breakfast.count
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell = Mview.dequeueReusableCellWithIdentifier("mealcell", forIndexPath: indexPath)
        let img = cell.viewWithTag(20) as! UIImageView!
        let title = cell.viewWithTag(21) as! UILabel!
        let subtitle = cell.viewWithTag(23) as! myUILabel!
        let money = cell.viewWithTag(22) as! UILabel!
        var  Meals = breakfast[1] as MealModel
        switch tag {
        case 1:
              Meals = breakfast[indexPath.row] as MealModel
        case 2:
              Meals = desert[indexPath.row] as MealModel
        case 3:
              Meals = dinner[indexPath.row] as MealModel
        default:
              Meals = breakfast[indexPath.row] as MealModel
        }
       
        img.image = UIImage(named:Meals.img)
        title.text=Meals.title
        subtitle.text=Meals.subtitle
        money.text = "\(Meals.money)元"
        subtitle.verticalAlignment=VerticalAlignmentTop
//        cell.selectionStyle = UITableViewCellSelectionStyle.None 

        return cell
    }
    func CheckMeal(title:String)->Int{
        switch title {
        case "早餐": return 1;
        case "正餐": return 3;
        case "甜点":return 2;
        default:return 0;
        }
    }
//    showdetail
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        var  Meals = breakfast[1] as MealModel
        switch tag {
        case 1:
            Meals = breakfast[indexPath.row] as MealModel
        case 2:
            Meals = desert[indexPath.row] as MealModel
        case 3:
            Meals = dinner[indexPath.row] as MealModel
        default:
            Meals = breakfast[indexPath.row] as MealModel
        }
       
        let deimg = Meals.img
        let detitle = Meals.title
        let desub = Meals.subtitle
        let demoney = "\(Meals.money)元"
        
        let MealDetail = MealModel(img: deimg, title: detitle, subtitle: desub, money: demoney)
        self.performSegueWithIdentifier("showdetail", sender: MealDetail)
        
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showdetail"{
            let controller = segue.destinationViewController as! DetailViewController
            controller.noticedetails = (sender! as! MealModel)
        }
    }

    
}

