//
//  Model.swift
//  Final
//
//  Created by Chan on 16/6/23.
//  Copyright © 2016年 Chan. All rights reserved.
//
//本地Model
class MealModel: NSObject {
    //定义model
    var img:String
    var title:String
    var subtitle:String
    var money:String
    //初始化数据
    init(img:String,title:String,subtitle:String,money:String) {
        self.img = img
        self.title = title
        self.subtitle=subtitle
        self.money=money
    }
}
class SetModel: NSObject {
    var img:String
    var title:String
    init(img:String,title:String) {
        self.img = img
        self.title = title
    }
}
class MsgModel: NSObject {
    var img:String
    var title:String
    init(img:String,title:String) {
        self.img = img
        self.title = title
    }
}
class OrderModel: NSObject {
    var img:String
    var title:String
    var time:String
    var type:String
    init(img:String,title:String,time:String,type:String) {
        self.img = img
        self.title = title
        self.time=time
        self.type=type
    }
}