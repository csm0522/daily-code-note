//
//  DetailView.swift
//  Final
//
//  Created by Chan on 16/6/24.
//  Copyright © 2016年 Chan. All rights reserved.
//

import Foundation
class DetailViewController: UIViewController {
    
        var noticedetails:MealModel!
        
        @IBOutlet weak var titlemsg: UILabel!
        @IBOutlet weak var showmoney: UILabel!
        @IBOutlet weak var contentmsg: myUILabel!
        @IBOutlet weak var showimg: UIImageView!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            titlemsg.text = noticedetails.title
            contentmsg.verticalAlignment=VerticalAlignmentTop
            contentmsg.text = noticedetails.subtitle
            showmoney.text=noticedetails.money
            showimg.image=UIImage(named: noticedetails.img)
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            
        }
        
        
}
