//
//  login.swift
//  Final
//
//  Created by Chan on 16/6/16.
//  Copyright © 2016年 Chan. All rights reserved.
//

import Foundation
import UIKit

class loginController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var pwd: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    override func viewDidLoad() {
        self.username.text = NSUserDefaults.standardUserDefaults().valueForKey("UserNameKey") as! String!
        self.pwd.text = NSUserDefaults.standardUserDefaults().valueForKey("PwdKey") as! String!
        
        let screenbounds:CGRect = UIScreen.mainScreen().bounds
        let backgroundImage = UIImageView(frame:UIScreen.mainScreen().bounds)
        backgroundImage.image = UIImage(named: "12ad77b3332ec8d61e36a6111a016683.jpeg")
        backgroundImage.frame = CGRect(x:0,y:0,width:screenbounds.size.width,height:screenbounds.size.height );   //指定图片的位置以及显示的大小
        
        self.view.insertSubview(backgroundImage, atIndex: 0)
        
    
        loginBtn.layer.borderColor = UIColor.whiteColor().CGColor
        loginBtn.layer.borderWidth=2
        loginBtn.layer.cornerRadius=15
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func Alogin(sender: AnyObject) {
        if(username.text!==""||pwd.text==""){
            noticeError("用户名或密码不能为空", autoClear: true , autoClearTime: 2);
        }
        else{
            let loginname:String = username.text!
            let password:String = pwd.text!
            NSUserDefaults.standardUserDefaults().setObject(loginname, forKey: "UserNameKey")
            NSUserDefaults.standardUserDefaults().setObject(password, forKey: "PwdKey")
            print("asdad");
            self.performSegueWithIdentifier("login", sender: self)
        }
    }
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?){
        username.resignFirstResponder()
        pwd.resignFirstResponder()
    }
    
}

