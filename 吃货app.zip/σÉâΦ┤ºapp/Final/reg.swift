//
//  reg.swift
//  Final
//
//  Created by Chan on 16/6/25.
//  Copyright © 2016年 Chan. All rights reserved.
//

import Foundation
import UIKit
class regcontroller:UIViewController,UITextFieldDelegate{
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var pwd: UITextField!
    @IBOutlet weak var repwd: UITextField!
    @IBOutlet weak var submits: UIButton!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        let screenbounds:CGRect = UIScreen.mainScreen().bounds
        let backgroundImage = UIImageView(frame:UIScreen.mainScreen().bounds)
        backgroundImage.image = UIImage(named: "12ad77b3332ec8d61e36a6111a016683.jpeg")
        backgroundImage.frame = CGRect(x:0,y:0,width:screenbounds.size.width,height:screenbounds.size.height );   //指定图片的位置以及显示的大小
        
        self.view.insertSubview(backgroundImage, atIndex: 0)
        
        submits.layer.borderColor = UIColor.whiteColor().CGColor
        submits.layer.borderWidth=2
        submits.layer.cornerRadius=15

        
    }
    @IBAction func reg(sender: AnyObject) {
        if(username.text==""||pwd.text==""||repwd.text==""){
            self.noticeError("不能为空", autoClear: true , autoClearTime: 2)
        }
        else{
            let user = username.text!
            let pwds = pwd.text!
            let subs = repwd.text!
            if(pwds != subs){
                self.noticeError("两次密码不对", autoClear: true, autoClearTime: 2)
            }
            else{
                
                NSUserDefaults.standardUserDefaults().setObject(user, forKey: "UserNameKey")
                NSUserDefaults.standardUserDefaults().setObject(pwds, forKey: "PwdKey")
                self.noticeSuccess("注册成功", autoClear: true, autoClearTime: 1)
                let mystoryboard = UIStoryboard(name: "Main" , bundle: nil).instantiateViewControllerWithIdentifier("login") as UIViewController
                self.presentViewController(mystoryboard, animated: true, completion: nil)
            }
        }
        
    }
}