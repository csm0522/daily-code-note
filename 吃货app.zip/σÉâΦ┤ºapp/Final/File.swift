//
//  DetailController.swift
//  Final
//
//  Created by Chan on 16/6/24.
//  Copyright © 2016年 Chan. All rights reserved.
//

import Foundation
import UIKit
class DetailController:UIViewController{
     var noticedetails:OrderModel!
    @IBOutlet weak var titles: UILabel!
    @IBOutlet weak var tims: UILabel!
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var subtitle: myUILabel!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        titles.text=noticedetails.title
        images.image=UIImage(named: noticedetails.img)
        tims.text=noticedetails.time
    }
}