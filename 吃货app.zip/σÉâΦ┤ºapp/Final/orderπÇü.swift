//
//  order、.swift
//  Final
//
//  Created by Chan on 16/6/24.
//  Copyright © 2016年 Chan. All rights reserved.
//

import Foundation
import UIKit
var unfinish:[OrderModel]=[]
var finish:[OrderModel]=[]
var order:[OrderModel] = []
var tags:Int=0
class oredercontroller : UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet weak var seg: UISegmentedControl!
    @IBOutlet weak var resview: UITableView!
    
    override func viewDidLoad() {
        self.automaticallyAdjustsScrollViewInsets=false
        unfinish=[OrderModel(img: "dinner1.jpeg", title: "香菇粉丝面", time: "2016-06-25 12:10", type:"1"),
        ]
        finish=[OrderModel(img: "desert1.jpeg", title: "蜂蜜水果茶", time: "2016-06-15 12:10", type: "2"),
                OrderModel(img: "desert4.jpeg", title: "糯米团子", time: "2016-06-15 15:10", type: "2"),
        ]
        if(tags==0){
            order=unfinish
        }
        else{
            order=finish
        }
        resview.dataSource=self
        resview.delegate=self
        resview.separatorColor=UIColor.clearColor()
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
       return order.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell = resview.dequeueReusableCellWithIdentifier("rescell", forIndexPath: indexPath)
        let img = cell.viewWithTag(30) as! UIImageView!
        let title = cell.viewWithTag(31) as! UILabel!
        let time  = cell.viewWithTag(32) as! UILabel!
        let orders = order[indexPath.row] as OrderModel!
        img.image = UIImage(named: orders.img)
        title.text = orders.title
        time.text = orders.time
        return cell
    }
    @IBAction func change(sender: AnyObject) {
        if(seg.selectedSegmentIndex==0){
             order=unfinish
        }
        else{
             order=finish
        }
        resview.reloadData()
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let  orders = order[indexPath.row] as OrderModel

        let deimg = orders.img
        let detitle = orders.title
        let desub = orders.time
        let type = orders.type
    
        self.noticeSuccess(detitle, autoClear: true , autoClearTime: 2)
        
        
    }
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        if segue.identifier == "showmsg"{
//            let controller = segue.destinationViewController as! DetailController
//            controller.noticedetails = (sender! as! OrderModel)
//        }
//    }

    
}