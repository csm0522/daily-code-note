//
//  setting.swift
//  Final
//
//  Created by Chan on 16/6/23.
//  Copyright © 2016年 Chan. All rights reserved.
//

import Foundation
import UIKit
import Social
var menu:[SetModel]=[]
let titleArr=["开发者信息","开发日志","技术支持","退出"]
class SettingController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var setview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.automaticallyAdjustsScrollViewInsets=false
        menu=[SetModel(img:"关于我们.png" , title: "开发者信息"),
              SetModel(img:"日志.png" , title: "开发日志"),
              SetModel(img:"技术类.png" , title: "技术支持"),
              SetModel(img:"退出.png" , title: "退出"),
        ]
        setview.dataSource=self
        setview.delegate=self
        setview.separatorColor=UIColor.clearColor()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return menu.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        let cell=setview.dequeueReusableCellWithIdentifier("setcell", forIndexPath: indexPath)
        let titles = cell.viewWithTag(21) as! UILabel!
        let pic = cell.viewWithTag(20) as! UIImageView!
        let setting=menu[indexPath.row] as SetModel
        titles.text=setting.title
        pic.image=UIImage(named: setting.img)
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        return cell
    }
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        print(indexPath.row)
       if indexPath.row == 3{
            let alertViewController:UIAlertController = UIAlertController(title:"提示", message:"你确定登出？", preferredStyle: UIAlertControllerStyle.Alert);
            
            let logoutbtn = UIAlertAction(title: "确定", style: UIAlertActionStyle.Default, handler: {(alert: UIAlertAction!) in//handler闭包
                
                let mystoryboard = UIStoryboard(name: "Main" , bundle: nil).instantiateViewControllerWithIdentifier("login") as UIViewController
                self.presentViewController(mystoryboard, animated: true, completion: nil)
            });
            
            let cancelbtn = UIAlertAction(title: "取消", style: UIAlertActionStyle.Default, handler: nil);
            
            alertViewController.addAction(cancelbtn);
            alertViewController.addAction(logoutbtn);
            
            self.presentViewController(alertViewController, animated: true, completion: nil);

        }
       else{
        
        let mystoryboard = UIStoryboard(name: "Main", bundle: nil).instantiateViewControllerWithIdentifier("support") as UIViewController
        mystoryboard.navigationItem.title="\(titleArr[indexPath.row])"
        mystoryboard.hidesBottomBarWhenPushed=true;
        self.navigationController?.pushViewController(mystoryboard, animated: true)
        }
    }
    
    @IBAction func twitter(sender: AnyObject) {
        let controller:SLComposeViewController=SLComposeViewController(forServiceType:SLServiceTypeTwitter)
        controller.setInitialText("一起来玩吃货app!")
        controller.addImage(UIImage(named: "icon@120.png"))
        self.presentViewController(controller,animated:true,completion:nil)//要不要动画，当他完成之后的call back

    }
    
   
    @IBAction func facebook(sender: AnyObject) {
        let controller:SLComposeViewController=SLComposeViewController(forServiceType:SLServiceTypeFacebook)
        controller.setInitialText("一起来玩吃货app!")
        controller.addImage(UIImage(named: "icon@120.png"))
        self.presentViewController(controller,animated:true,completion:nil)//要不要动画，当他完成之后的call back
    }
}

